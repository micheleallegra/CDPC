function Crap(varargin)

global The_files_to_cluster
global The_mask

global connectedcut
global interactive
global vol_begin
global vol_end
global winlen
global NCUT
global SPATIALCUT
global RHO
global NCLUST_MAX

connectedcut=0;
interactive=0;
NCUT=200;
SPATIALCUT=5;
RHO=0;
NCLUST_MAX=10;
vol_begin=1;
vol_end=1;
winlen=12;


The_files_to_cluster=[];
The_mask=[];

global defaults    %%% def. spm parameters
global st



    try
        if numel(defaults)==0
            try
                spm_defaults;
            catch
                try
                    spm('ChMod','FMRI')
                end
            end
        end
        defaults.oldDefaults = defaults;
    end



fg = depict_figure('GetWin','Graphics1');


if isempty(fg), error('Can''t create graphics window'); end
depict_figure('Clear','Graphics1');

set(gcf,'DefaultUicontrolFontSize',spm('FontSizes',get(gcf,'DefaultUicontrolFontSize')));

WS = spm('WinScale');

    st.SPM = spm('FnBanner');

uicontrol(fg,'Style','Text','Position',[25 680 550 75].*WS,'String','DEnsity Peak Image Clustering Toolbox (DEPICT) v0.5',...
    'FontSize',30,'FontWeight','bold','BackgroundColor',[1 1 1],'HorizontalAlignment','Center');


uicontrol(fg,'Style','PushButton','Units','normalized','Position',[.05 .70 .9 .055],'Callback','depict_select_input_files;',...
    'String','Select input files','FontSize',spm('FontSizes',12));

uicontrol(fg,'Style','PushButton','Units','normalized','Position',[.05 .70-2*0.075 .9 .055],'Callback','depict_select_mask;',...
    'String','Select mask','FontSize',spm('FontSizes',12));

uicontrol(fg,'Style','PushButton','Units','normalized','Position',[.05 .70-4*0.075 .9 0.055],'Callback','depict_select_parameters;',...
    'String','Select options','FontSize',spm('FontSizes',12));

uicontrol(fg,'Style','PushButton','Units','normalized','Position',[.05 .70-6*0.075 .9 0.055],'Callback','depict_apply;',...
    'String','Apply','FontSize',spm('FontSizes',12));


uicontrol(fg,'Style','PushButton','Units','normalized','Position',[.9 .01 .05 .03],'Callback','depict_exit;',...
    'String',{'Quit'},'FontSize',spm('FontSizes',10));

























