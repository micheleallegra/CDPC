./brain_cluster.exe  -C data/txt/coordinates.txt  -I data/txt/simulated_data_snr20.txt -OUTPUTNAME data/txt/simulated_data_snr20
